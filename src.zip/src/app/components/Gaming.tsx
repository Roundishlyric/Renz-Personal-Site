import { Trophy, Gamepad2, Users, TrendingUp, Twitch, Youtube, Award, Medal, Target, Swords } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Gaming() {
  const teamMembers = [
    {
      name: 'PlayerOne',
      role: 'Team Captain',
      game: 'Street Fighter 6',
      image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&q=80',
    },
    {
      name: 'YourTag',
      role: 'Main Fighter',
      game: 'Multiple Titles',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&q=80',
      isYou: true,
    },
    {
      name: 'ProGamer3',
      role: 'Sub Fighter',
      game: 'Tekken 8',
      image: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=400&q=80',
    },
    {
      name: 'Fighter4',
      role: 'Analyst',
      game: 'Strategy',
      image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&q=80',
    },
  ];

  const tournaments = [
    {
      name: 'EVO 2025 - Street Fighter 6',
      placement: '1st Place',
      prize: '$5,000',
      date: 'August 2025',
      participants: '2,500+',
      badge: 'gold',
    },
    {
      name: 'Combo Breaker 2025',
      placement: '2nd Place',
      prize: '$2,500',
      date: 'May 2025',
      participants: '1,200+',
      badge: 'silver',
    },
    {
      name: 'CEO Fighting Game Championships',
      placement: '3rd Place',
      prize: '$1,000',
      date: 'June 2025',
      participants: '800+',
      badge: 'bronze',
    },
    {
      name: 'Tekken World Tour Regional',
      placement: '1st Place',
      prize: '$3,000',
      date: 'March 2025',
      participants: '500+',
      badge: 'gold',
    },
    {
      name: 'Local Fighting Game League',
      placement: '1st Place',
      prize: '$500',
      date: 'February 2025',
      participants: '150+',
      badge: 'gold',
    },
    {
      name: 'Online Championship Series',
      placement: '4th Place',
      prize: '$750',
      date: 'January 2025',
      participants: '1,000+',
      badge: 'participant',
    },
  ];

  const fightingGames = [
    {
      title: 'Street Fighter 6',
      rank: 'Master Rank',
      hours: '2,500+',
      main: 'Ryu / Ken',
      winRate: '68%',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80',
    },
    {
      title: 'Tekken 8',
      rank: 'Tekken God',
      hours: '1,800+',
      main: 'Jin / Kazuya',
      winRate: '65%',
      image: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=800&q=80',
    },
    {
      title: 'Mortal Kombat 1',
      rank: 'Grand Master',
      hours: '1,200+',
      main: 'Scorpion / Sub-Zero',
      winRate: '62%',
      image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&q=80',
    },
    {
      title: 'Guilty Gear Strive',
      rank: 'Celestial',
      hours: '900+',
      main: 'Sol Badguy',
      winRate: '60%',
      image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&q=80',
    },
  ];

  const achievements = [
    {
      icon: Trophy,
      title: 'Tournament Champion',
      description: 'Multiple 1st place finishes in major tournaments',
      count: '5x',
    },
    {
      icon: Medal,
      title: 'Top 8 Finishes',
      description: 'Consistent top performer in competitive scene',
      count: '20+',
    },
    {
      icon: Target,
      title: 'Win Rate',
      description: 'Overall competitive win rate across all games',
      count: '65%',
    },
    {
      icon: Swords,
      title: 'Main Games',
      description: 'Competitive fighting game titles',
      count: '8+',
    },
  ];

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case 'gold':
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white';
      case 'silver':
        return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white';
      case 'bronze':
        return 'bg-gradient-to-r from-orange-400 to-orange-600 text-white';
      default:
        return 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white';
    }
  };

  return (
    <section id="gaming" className="py-20 bg-gradient-to-br from-slate-900 via-teal-900 to-slate-900 text-white pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Introduction */}
        <div className="text-center mb-20">
          <div className="mb-8">
            <div className="inline-block p-1 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full">
              <div className="bg-slate-900 rounded-full p-1">
                <div className="w-40 h-40 bg-gradient-to-br from-teal-900 to-cyan-900 rounded-full flex items-center justify-center overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&q=80"
                    alt="Player Profile"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-3 mb-4">
            <Gamepad2 size={40} className="text-teal-400" />
            <h1 className="text-5xl md:text-6xl text-white">Your Gamertag</h1>
          </div>
          
          <div className="w-20 h-1 bg-gradient-to-r from-teal-500 to-cyan-500 mx-auto mb-6"></div>
          
          <h2 className="text-2xl md:text-3xl text-teal-400 mb-6">
            Professional Fighting Game Competitor
          </h2>
          
          <p className="text-lg text-gray-300 max-w-3xl mx-auto mb-4">
            Competing at the highest level in fighting game tournaments worldwide. 
            Specializing in Street Fighter 6, Tekken 8, and multiple fighting game titles.
          </p>
          
          <p className="text-md text-gray-400 max-w-2xl mx-auto mb-8">
            With over 5 years of competitive experience, I've secured multiple championship titles 
            and consistently place in top 8 at major tournaments. Currently representing Team Apex Fighters.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Badge className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white text-lg px-6 py-2">
              🏆 5x Champion
            </Badge>
            <Badge className="bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-lg px-6 py-2">
              ⚔️ Fighting Game Specialist
            </Badge>
            <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-lg px-6 py-2">
              👥 Team Apex Fighters
            </Badge>
          </div>
        </div>

        {/* Achievements Overview */}
        <div className="mb-20">
          <h3 className="text-3xl mb-10 text-center">Competition Stats</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <Card
                  key={index}
                  className="bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-teal-500/30 hover:border-teal-500 transition-all p-6 backdrop-blur-sm hover:shadow-2xl hover:shadow-teal-500/20"
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="p-4 bg-gradient-to-br from-teal-600/30 to-cyan-600/30 rounded-full mb-4 border-2 border-teal-500/50">
                      <Icon className="text-teal-400" size={32} />
                    </div>
                    <div className="text-4xl font-bold text-teal-400 mb-2">{achievement.count}</div>
                    <h4 className="text-xl mb-2 text-white">{achievement.title}</h4>
                    <p className="text-gray-300 text-sm">{achievement.description}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-3xl mb-4">Team Apex Fighters</h3>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Competing together as one of the top fighting game teams in the region
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {teamMembers.map((member, index) => (
              <Card
                key={index}
                className={`bg-slate-800 border-2 overflow-hidden transition-all hover:shadow-2xl group ${
                  member.isYou 
                    ? 'border-teal-500 shadow-lg shadow-teal-500/30' 
                    : 'border-slate-700 hover:border-teal-500 hover:shadow-teal-500/20'
                }`}
              >
                <div className="relative h-48 overflow-hidden bg-slate-900">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent"></div>
                  {member.isYou && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-gradient-to-r from-teal-500 to-cyan-500">You</Badge>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h4 className="text-xl mb-1 text-white">{member.name}</h4>
                  <p className="text-teal-400 mb-2">{member.role}</p>
                  <p className="text-gray-400 text-sm">{member.game}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Tournament Placements */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-3xl mb-4">Tournament Placements</h3>
            <p className="text-gray-300">Recent competitive achievements and prize winnings</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tournaments.map((tournament, index) => (
              <Card
                key={index}
                className="bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-slate-700 hover:border-teal-500 transition-all hover:shadow-xl hover:shadow-teal-500/20"
              >
                <div className={`h-2 ${getBadgeColor(tournament.badge)}`}></div>
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h4 className="text-xl mb-2 text-white">{tournament.name}</h4>
                      <Badge className={`${getBadgeColor(tournament.badge)} mb-2`}>
                        {tournament.placement}
                      </Badge>
                    </div>
                    <div className="text-right ml-2">
                      <div className="text-2xl text-teal-400 font-bold">{tournament.prize}</div>
                    </div>
                  </div>
                  <div className="space-y-2 text-gray-300 text-sm">
                    <p>📅 {tournament.date}</p>
                    <p>👥 {tournament.participants} Participants</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Fighting Games */}
        <div className="mb-20">
          <h3 className="text-3xl mb-10 text-center">Main Fighting Games</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {fightingGames.map((game, index) => (
              <Card
                key={index}
                className="bg-slate-800 border-2 border-slate-700 overflow-hidden hover:border-teal-500 transition-all hover:shadow-2xl hover:shadow-teal-500/20 group"
              >
                <div className="relative h-40 overflow-hidden bg-slate-900">
                  <ImageWithFallback
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/70 to-transparent"></div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <Badge className="bg-teal-600 mb-2">
                      {game.hours} Hours
                    </Badge>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="text-lg mb-2 text-white">{game.title}</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-teal-400">🏅 {game.rank}</p>
                    <p className="text-gray-300">🎮 Main: {game.main}</p>
                    <p className="text-cyan-400">📊 Win Rate: {game.winRate}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Stats Summary */}
        <div className="text-center">
          <Card className="bg-gradient-to-br from-teal-900/50 to-slate-900/50 border-2 border-teal-700 backdrop-blur-sm max-w-5xl mx-auto">
            <div className="p-8">
              <h3 className="text-3xl mb-8 text-white">Career Overview</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                <div className="p-4 bg-slate-800/50 rounded-lg border border-teal-500/30">
                  <div className="text-4xl mb-2 text-teal-400 font-bold">6,400+</div>
                  <div className="text-gray-300">Total Hours</div>
                </div>
                <div className="p-4 bg-slate-800/50 rounded-lg border border-teal-500/30">
                  <div className="text-4xl mb-2 text-teal-400 font-bold">25+</div>
                  <div className="text-gray-300">Tournaments</div>
                </div>
                <div className="p-4 bg-slate-800/50 rounded-lg border border-teal-500/30">
                  <div className="text-4xl mb-2 text-yellow-400 font-bold">5</div>
                  <div className="text-gray-300">Championships</div>
                </div>
                <div className="p-4 bg-slate-800/50 rounded-lg border border-teal-500/30">
                  <div className="text-4xl mb-2 text-teal-400 font-bold">$15K+</div>
                  <div className="text-gray-300">Prize Money</div>
                </div>
                <div className="p-4 bg-slate-800/50 rounded-lg border border-teal-500/30">
                  <div className="text-4xl mb-2 text-teal-400 font-bold">Top 5</div>
                  <div className="text-gray-300">Regional Rank</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}